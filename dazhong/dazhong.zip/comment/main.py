from scrapy import cmdline
cmdline.execute("scrapy crawl comment".split())
# cmdline.execute("scrapy crawl comment -o comment.csv".split())